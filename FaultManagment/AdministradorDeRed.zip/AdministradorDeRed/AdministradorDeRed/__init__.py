from flask import Flask, render_template, request, flash, abort
from flask_api import status
import pingpuller
import json
import os

app = Flask(__name__)
app.secret_key = "12345"

@app.route('/')
def index():
    return render_template('index.html')


@app.route('/ping-puller', methods=['GET', 'POST'])
def getPingPuller():
    if request.method == 'GET':
        return render_template('ping-puller.html')

    if request.method == 'POST':
        telnet_host = request.form['host']
        passsword = request.form['telnet_password']
        enable_password = request.form['enable_password']
        tn, mssg = pingpuller.conectar_telnet(telnet_host, passsword, enable_password)
        if tn == None:
            if mssg.find("Interrupcion") != -1:
                abort(502)
            else:
                abort(401)

        subnets = pingpuller.obtener_subredes_telnet(tn)
        tn.close()

        data = pingpuller.getJsonPingPuller(subnets)
        return data
    return render_template('index.html')

if __name__ == '__main__':
    app.run(host="127.0.0.1", port=int("8080"), debug=True)